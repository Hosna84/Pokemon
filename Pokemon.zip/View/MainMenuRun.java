package View;

import java.util.Scanner;

import static Controller.MainMenu.startGame;

public class MainMenuRun {
    private static boolean invalidCommand;

    public static void run(Scanner scanner) {
        while (true) {
            invalidCommand = true;
            String input = scanner.nextLine();
            if (input.trim().equals("logout")) break;
            if (input.equals("show current menu")) {
                System.out.println("main menu");
                invalidCommand = false;
            }
            if (input.equals("go to shop menu")) {
                ShopMenuRun.run(scanner);
                invalidCommand = false;
            }
            if (input.equals("go to profile menu")) {
                ProfileManuRun.run(scanner);
                invalidCommand = false;
            }
            if (input.matches("start new game with (?<username>.*)")) {
                String regex = "start new game with (?<username>.*)";
                startGame(input, regex, scanner);
                invalidCommand = false;
            } else if (invalidCommand){
                System.out.println("invalid command");
            }
        }
    }
}
