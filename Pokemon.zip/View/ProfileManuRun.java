package View;

import Model.Cards;
import Model.User;

import java.util.Scanner;

import static Controller.ProfileMenu.*;
import static View.Print.printingString;
import static View.Print.printingStringBuilder;

public class ProfileManuRun {
    private static int flagForInvalid;
    public static Cards cardss;
    private static boolean invalidCommand;
    public static void run(Scanner scanner) {
        while (true) {
            invalidCommand = true;
            String input = scanner.nextLine();
            if (input.trim().equals("back")) break;
            if (input.trim().matches("show\\s+current\\s+menu")) {
                printingString("profile menu");
                invalidCommand = false;
            }
            if (input.trim().matches("show\\s+coins")) {
                printingString("number of coins:" + User.getLoggedInUser().getCoin());
                invalidCommand = false;
            }
            if (input.trim().matches("show\\s+experience")) {
                int exp = User.getLoggedInUser().getExperience();
                printingString("experience:" + exp);
                invalidCommand = false;
            }
            if (input.trim().matches("show\\s+storage")) {
                StringBuilder resultForStorage = new StringBuilder();
                printingStringBuilder(showingStorage(resultForStorage));
                invalidCommand = false;
            }
            if (input.trim().matches("equip\\s+card\\s+(?<cardname>\\S+)\\s+to\\s+my\\s+deck")) {
                String regex = "equip\\s+card\\s+(?<cardname>\\S+)\\s+to\\s+my\\s+deck";
                addingCard(input.trim(), regex);
                invalidCommand = false;
            }
            if (input.trim().matches("unequip\\s+card\\s+(?<cardname>\\S+)\\s+from my deck")) {
                String regex = "unequip\\s+card\\s+(?<cardname>\\S+)\\s+from\\s+my\\s+deck";
                unequipCard(input.trim(), regex);
                invalidCommand = false;
            }
            if (input.trim().matches("show\\s+my\\s+deck")) {
                showDeck();
                invalidCommand = false;
            }
            if (input.trim().matches("show\\s+my\\s+rank")) {
                User.rankObjects(User.getUsers());
                printingString("your rank:" + User.getLoggedInUser().getRank());
                invalidCommand = false;
            }
            if (input.trim().matches("show\\s+ranking")) {
                User.rankObjects(User.getUsers());
                invalidCommand = false;
                showAllRanks();
            } else if (invalidCommand){
                printingString("invalid command");
            }
        }
    }

}
