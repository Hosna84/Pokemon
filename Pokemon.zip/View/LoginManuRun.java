package View;

import java.util.Scanner;

import static Controller.LoginMenu.loginUser;
import static Controller.LoginMenu.registerUser;

public class LoginManuRun {
private static boolean invalidCommand;
    public static void run(Scanner scanner) {
        while (true) {
            String input = scanner.nextLine();
            invalidCommand = true;
            if (input.equals("exit")) break;
            if (input.equals("show current menu")) {
                System.out.println("login menu");
                invalidCommand = false;
            }
            if (input.matches("^\\s*register\\s+username\\s+(?<username>\\S+)\\s+password\\s+(?<password>\\S+)\\s+email\\s+(?<email>\\S+)\\s*$")) {
                String regex = "^\\s*register\\s+username\\s+(?<username>\\S+)\\s+password\\s+(?<password>\\S+)\\s+email\\s+(?<email>\\S+)\\s*$";
                registerUser(input, regex);
                invalidCommand = false;
            }
            if (input.matches("^\\s*login\\s+username\\s+(?<username>\\S+)\\s+password\\s+(?<password>\\S+)\\s*$")) {
                String regex = "^\\s*login\\s+username\\s+(?<username>\\S+)\\s+password\\s+(?<password>\\S+)\\s*$";
                loginUser(input, regex, scanner);
                invalidCommand = false;
            } else if (invalidCommand){
                System.out.println("invalid command");
            }
        }
    }

}
