package View;

public class Print {
    public static void printingStringBuilder(StringBuilder result){
        System.out.print(result);
    }
    public static void printingString(String result){
        System.out.println(result);
    }
}
