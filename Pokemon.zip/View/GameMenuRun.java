package View;

import Model.Side;
import Model.User;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static Controller.Gamemenu.*;
import static View.Print.printingString;

public class GameMenuRun {
    public static User currentUser;
    public static User notCurrentUser;
    public static Side currecntSide;
    public static Side notCurrentSide;
    public static int putEnergy;
    public static int round;
    private static boolean invalidCommand;

    public static void run(Scanner scanner, User user1, User user2) {
        Side side1 = new Side(user1);
        Side side2 = new Side(user2);
        notCurrentUser = user2;
        currentUser = user1;
        currecntSide = side1;
        notCurrentSide = side2;
        round = 1;
        putEnergy = 0;
        user1.serKill(-user1.getKilled());
        user2.serKill(-user2.getKilled());
        while (true) {
            invalidCommand = true;
            String input = scanner.nextLine();
            if (input.trim().matches("show\\s+current\\s+menu")) {
                printingString("game menu");
                invalidCommand = false;
            }
            if (input.trim().matches("put\\s+card\\s+(?<cardname>\\S+)\\s+to\\s+(?<placenumber>.*)")) {
                String regex = "put\\s+card\\s+(?<cardname>\\S+)\\s+to\\s+(?<placenumber>.*)";
                Matcher matcher = getCommandMatcher(input.trim(), regex);
                putCard(matcher, currentUser);
                invalidCommand = false;
            }
            if (input.trim().matches("show\\s+table")) {
                showingTable();
                invalidCommand = false;
            }
            if (input.trim().matches("show\\s+my\\s+info\\s+(?<placenumber>.*)")) {
                String regex = "show\\s+my\\s+info\\s+(?<placenumber>.*)";
                Matcher matcher = getCommandMatcher(input.trim(), regex);
                showMyInfo(matcher);
                invalidCommand = false;
            }

            if (input.trim().matches("show\\s+enemy\\s+info\\s+(?<placenumber>.*)")) {
                String regex = "show\\s+enemy\\s+info\\s+(?<placenumber>.*)";
                Matcher matcher = getCommandMatcher(input.trim(), regex);
                showEnemyInfo(matcher);
                invalidCommand = false;
            }
            if (input.trim().matches("substitute\\s+active\\s+card\\s+with\\s+bench\\s+(?<benchnumber>.*)")) {

                String regex = "substitute\\s+active\\s+card\\s+with\\s+bench\\s+(?<benchnumber>.*)";
                Matcher matcher = getCommandMatcher(input.trim(), regex);
                changeActiveCard(matcher);
                invalidCommand = false;
            }
            if (input.trim().contains("execute") && input.trim().contains("action")) {
                invalidCommand = false;
                int isExecuted = executeAction(input);
                if (isExecuted == 1) {
                    if (doIHaveAnyPokemonInActiveBench()) {
                        if (currecntSide.getActive0() != null)
                            currecntSide.getActive0().setAsleep(false);
                        eachCardForItsSelfBurning();
                        changeBurningMode();
                        swapingThings(user1, user2, side1, side2);
                        printingString(currentUser.getUsername() + "'s turn");
                    } else {
                        printingString("Winner: " + notCurrentUser.getUsername());
                        calculatingExp(user1, user2, side2);
                        calculatingExp(user2, user1, side1);
                        caculatingReduceForTheLastTime(user1, side2);
                        caculatingReduceForTheLastTime(user2, side1);
                        calculateExpAndCoin(user1);
                        calculateExpAndCoin(user2);
                        break;
                    }
                } else if (isExecuted == 0) {
                    continue;
                }
            }


            if (input.trim().matches("end\\s+turn")) {
                invalidCommand = false;
                if (!doIHaveAnyPokemonInActiveBench()) {
                    printingString("Winner: " + notCurrentUser.getUsername());
                    calculatingExp(user1, user2, side2);
                    calculatingExp(user2, user1, side1);
                    caculatingReduceForTheLastTime(user1, side2);
                    caculatingReduceForTheLastTime(user2, side1);
                    calculateExpAndCoin(user1);
                    calculateExpAndCoin(user2);
                    break;
                } else {
                    eachCardForItsSelfBurning();
                    if (currecntSide.getActive0() != null)
                        currecntSide.getActive0().setAsleep(false);
                    changeBurningMode();
                    swapingThings(user1, user2, side1, side2);
                    printingString(currentUser.getUsername() + "'s turn");
                }

            } else if (invalidCommand){
                printingString("invalid command");
            }

        }
    }

    private static Matcher getCommandMatcher(String input, String regex) {
        Pattern pattern = Pattern.compile(regex);

        return pattern.matcher(input);
    }
}
