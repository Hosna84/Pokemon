package View;

import java.util.Scanner;

import static Controller.ShopMenu.buyCard;
import static Controller.ShopMenu.sellingCards;
import static View.Print.printingString;

public class ShopMenuRun {
    private static boolean invalidCommand;
    public static void run(Scanner scanner) {
        while (true) {
            invalidCommand = true;
            String input = scanner.nextLine();
            if (input.equals("back")) break;
            if (input.equals("show current menu")) {
                printingString("shop menu");
                invalidCommand = false;
            }
            if (input.matches("buy card (?<cardname>.*)")) {
                String regex = "buy card (?<cardname>.*)";
                buyCard(input, regex);
                invalidCommand = false;
            }
            if (input.matches("sell card (?<cardname>.*)")) {
                String regex = "sell card (?<cardname>.*)";
                sellingCards(input, regex);
                invalidCommand = false;
            } else if (invalidCommand){
                printingString("invalid command");
            }
        }
    }
}
