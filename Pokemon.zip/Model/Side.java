package Model;

public class Side {


    private User user;
    private Pokemon active0;
    private Pokemon bench1;
    private Pokemon bench2;
    private Pokemon bench3;


    public Side(User user) {
        this.user = user;
        this.active0 = null;
        this.bench1 = null;
        this.bench2 = null;
        this.bench3 = null;
    }

    public Pokemon getActive0() {
        return active0;
    }

    public void setActive0(Pokemon pokemon) {
        this.active0 = pokemon;
    }

    public Pokemon getBench1() {
        return bench1;
    }

    public void setBench1(Pokemon pokemon) {
        this.bench1 = pokemon;
    }

    public void setBench2(Pokemon pokemon) {
        this.bench2 = pokemon;
    }

    public void setBench3(Pokemon pokemon) {
        this.bench3 = pokemon;
    }

    public void setEnergyFor0(Energy energy) {
        this.active0.addToEnergyCards(energy);
    }

    public void setEnergyFor1(Energy energy) {
        this.bench1.addToEnergyCards(energy);
    }

    public void setEnergyFor2(Energy energy) {
        this.bench2.addToEnergyCards(energy);
    }

    public void setEnergyFor3(Energy energy) {
        this.bench3.addToEnergyCards(energy);
    }

    public Pokemon getBench2() {
        return bench2;
    }

    public Pokemon getBench3() {
        return bench3;
    }


}
