package Model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Pokemon extends Cards {
    private boolean isAsleep;
    private boolean isBurning;
    private boolean isParalized;
    private double resistance;
    private double remainingHitPoint;
    private double maxHitPoint;
    private int power;
    private ArrayList<Energy> energyCards = new ArrayList<>();
    private Map<String, Double> weakness = new HashMap<>();

    public Pokemon(String cardName, String type, boolean isPokemon, boolean isAsleep, boolean isBurning,
                   boolean isParalized, double resistance, double remainingHitPoint, double maxHitPoint, int power) {
        super(cardName, type, isPokemon);
        this.isAsleep = false;
        this.isBurning = false;
        this.isParalized = false;
        this.maxHitPoint = maxHitPoint;
        this.resistance = resistance;
        this.remainingHitPoint = maxHitPoint;
        this.power = power;

    }

    public void assigningWeakness(double waeknessForFire, double weaknessForWater, double weaknessForplant) {
        this.weakness.put("fire", waeknessForFire);
        this.weakness.put("water", weaknessForWater);
        this.weakness.put("plant", weaknessForplant);
    }

    public void setAsleep(boolean asleep) {
        this.isAsleep = asleep;
    }

    public void setBurning(boolean isBurning) {
        this.isBurning = isBurning;
    }
    public void setCompeleteEnergy(ArrayList<Energy> energy){
        this.energyCards = energy;
    }

    public double getWeakness(String key) {
        return weakness.get(key);
    }

    public ArrayList getEnergyCards() {
        return this.energyCards;
    }


    public void addToEnergyCards(Energy energy) {
        if(this.energyCards!=null)
            this.energyCards.add(energy);
    }

    public boolean getIsBurning() {
        return this.isBurning;
    }

    public boolean isAsleep() {
        return this.isAsleep;
    }

    public double getRemainingHitPoint() {
        return this.remainingHitPoint;
    }
    public void setRemainingHitPoint(double damage){
        this.remainingHitPoint+=damage;
    }
    public int getPower(){
        return this.power;
    }
    public double getResistance(){
        return this.resistance;
    }

    public double getMaxHitPoint() {
        return  this.maxHitPoint;
    }
}
