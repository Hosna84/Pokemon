package Model;


import java.util.HashMap;
import java.util.Map;

public class Energy extends Cards{

    private Map<String, Double> energy = new HashMap<>();
    public Energy(String cardName, String type, boolean isPokemon) {
        super(cardName, type, isPokemon);

    }
    public void setEnergy(double fire,double water,double plant){
        energy.put("fire",fire);
        energy.put("water",water);
        energy.put("plant",plant);

    }
    public double getEnergy(String darBarabarWichType){
        return energy.get(darBarabarWichType);
    }



}
