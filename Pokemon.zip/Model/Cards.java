package Model;

public class Cards {
    private String cardName;
    private String type;
    private boolean isEqipped;
    boolean isPokemon;
    public Cards(String cardName,String type,boolean isPokemon){
        this.cardName = cardName;
        this.type = type;
        isEqipped = false;
        this.isPokemon=isPokemon;
    }
    public String getCardName(){
        return this.cardName;
    }
    public boolean getIsEqipped(){
        return this.isEqipped;
    }
    public boolean getIsPokemon(){
        return this.isPokemon;
    }
    public void setIsEqipped(boolean isEqipped){
        this.isEqipped = isEqipped;
    }
    public String getType(){
        return this.type;
    }

}
