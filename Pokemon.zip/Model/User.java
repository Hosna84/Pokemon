package Model;

import java.util.ArrayList;
import java.util.Comparator;

public class User {
    private String userName;
    private String password;
    private int experience;
    private int coin;
    private int rank;
    private double reduce;
    private int killed;
    private static User loggedinUser;
    private static ArrayList<User> users = new ArrayList<>();
    private static ArrayList<String> userNames = new ArrayList<>();
    private ArrayList<Cards> cards = new ArrayList<>();

    private ArrayList<Cards> deckCards = new ArrayList<>();

    public User(String userName, String password) {
        this.userName = userName;
        this.password = password;
        users.add(this);
        userNames.add(userName);
        this.experience = 0;
        this.coin = 300;
        this.reduce = 0;
        this.killed = 0;
    }

    public static ArrayList<User> getUsers() {
        return users;
    }

    public ArrayList getDeckCards() {
        return this.deckCards;
    }

    public String getUsername() {
        return this.userName;
    }

    public int getCoin() {
        return coin;
    }

    public int getExperience() {
        return experience;
    }
    public void setExperience(int experience){
        this.experience = experience;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public int getRank() {
        return this.rank;
    }

    public static void rankObjects(ArrayList<User> users) {
        users.sort(Comparator.comparingInt(User::getExperience).reversed().thenComparing(User::getUsername));

        for(int i=0;i<users.size();i++){
            users.get(i).setRank(i+1);
        }
    }

    public static ArrayList getUserNames() {
        return userNames;
    }

    public static User getUserByUsername(String username) {
        for (int q = 0; q < users.size(); q++) {
            if (users.get(q).getUsername().equals(username)) {
                return users.get(q);
            }
        }
        return null;
    }

    public String getPassword() {
        return this.password;
    }

    public void setCoin(int newCoin) {
        this.coin = newCoin;
    }

    public void setReduce(double reduce) {
        this.reduce += reduce;
    }

    public void serKill(int killed) {
        this.killed += killed;
    }
    public int getKilled(){
        return this.killed;
    }
    public double getReduce(){
        return this.reduce;
    }

    public static void setLoggedinUser(User user) {
        loggedinUser = user;
    }

    public void setDeckCards(Cards cards) {
        this.deckCards.add(cards);
    }

    public static User getLoggedInUser() {
        return loggedinUser;
    }

    public void addCardsToArrayList(Cards cards) {
        this.cards.add(cards);

    }

    public ArrayList getCards() {
        return this.cards;
    }

    public void deleteCards(Cards cards) {
        this.cards.remove(cards);
    }

    public void deleteDeckCards(Cards cards) {
        this.deckCards.remove(cards);
    }

    public Cards getCardBynameInCards(String cardName) {
        for (int i = 0; i < this.cards.size(); i++) {
            if (cards.get(i).getCardName().equals(cardName))
                return cards.get(i);
        }
        return null;
    }

    public Cards getCardBynameInDeckCards(String cardName) {
        for (int i = 0; i < this.deckCards.size(); i++) {
            if (deckCards.get(i).getCardName().equals(cardName))
                return deckCards.get(i);
        }
        return null;
    }

}
