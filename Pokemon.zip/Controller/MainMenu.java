package Controller;

import Model.User;
import View.GameMenuRun;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static View.Print.printingString;

public class MainMenu {
    public static void startGame(String input, String regex, Scanner scanner) {
        Pattern patternForStartGame = Pattern.compile(regex);
        Matcher matcher = patternForStartGame.matcher(input);
        if (matcher.matches()) {
            String userName = matcher.group("username");
            ArrayList<String> userNames = User.getUserNames();
            if (!(userNames.contains(userName))) {
                printingString("username is incorrect");
                return;
            }
            if ((User.getLoggedInUser().getDeckCards().size() < 12)) {
                printingString(User.getLoggedInUser().getUsername() + " has no 12 cards in deck");
                return;
            }
            if (User.getUserByUsername(userName).getDeckCards().size() < 12) {
                printingString(userName + " has no 12 cards in deck");
                return;
            }
            GameMenuRun.run(scanner, User.getLoggedInUser(), User.getUserByUsername(userName));
        }
    }
}

