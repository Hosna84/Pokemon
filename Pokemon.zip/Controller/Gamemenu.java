package Controller;

import Model.*;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static View.GameMenuRun.*;
import static View.Print.printingString;
import static View.Print.printingStringBuilder;

public class Gamemenu {
    public static void changeBurningMode() {
        if (currecntSide.getActive0() != null) currecntSide.getActive0().setBurning(false);
        if (currecntSide.getBench1() != null) currecntSide.getBench1().setBurning(false);
        if (currecntSide.getBench2() != null) currecntSide.getBench2().setBurning(false);
        if (currecntSide.getBench3() != null) currecntSide.getBench3().setBurning(false);
    }

    public static void calculatingExp(User me, User U, Side you) {
        int killed = 12;
        killed -= U.getDeckCards().size();
        if (you.getActive0() != null) {
            killed--;
            ArrayList<Energy> energy = you.getActive0().getEnergyCards();
            for (int i = 0; i < energy.size(); i++) {
                if (energy.get(i) != null) killed--;
            }
        }
        if (you.getBench1() != null) {
            killed--;
            ArrayList<Energy> energy = you.getBench1().getEnergyCards();
            if (energy != null) {
                for (int i = 0; i < energy.size(); i++) {
                    if (energy.get(i) != null) killed--;
                }
            }
        }
        if (you.getBench2() != null) {
            killed--;
            ArrayList<Energy> energy = you.getBench2().getEnergyCards();
            if (energy != null) {
                for (int i = 0; i < energy.size(); i++) {
                    if (energy.get(i) != null) killed--;
                }
            }
        }
        if (you.getBench3() != null) {
            killed--;
            ArrayList<Energy> energy = you.getBench3().getEnergyCards();
            if (energy != null) {
                for (int i = 0; i < energy.size(); i++) {
                    if (energy.get(i) != null) killed--;
                }
            }
        }
        me.serKill(killed);
    }

    public static void caculatingReduceForTheLastTime(User user, Side side) {
        double reduce = 0;
        if (side.getActive0() != null) {
            reduce += Math.abs(side.getActive0().getMaxHitPoint() -
                    side.getActive0().getRemainingHitPoint());
        }
        if (side.getBench1() != null) {
            reduce += Math.abs(side.getBench1().getMaxHitPoint() -
                    side.getBench1().getRemainingHitPoint());
        }
        if (side.getBench2() != null) {
            reduce += Math.abs(side.getBench2().getMaxHitPoint() -
                    side.getBench2().getRemainingHitPoint());
        }
        if (side.getBench3() != null) {
            reduce += Math.abs(side.getBench3().getMaxHitPoint() -
                    side.getBench3().getRemainingHitPoint());
        }
        user.setReduce(reduce);

    }

    public static int executeAction(String input) {

        if (input.contains("-t")) {
            int returnn = executeActionWithTarget(input);
            if (returnn == 1) return 1;
            if (returnn == 0) return 0;
        } else {
            int returnn = executeActionWithoutTarget(input);
            if (returnn == 1) return 1;
            if (returnn == 0) return 0;
        }
        return 0;
    }

    private static int executeActionWithoutTarget(String input) {
        if (!doIHaveAnyPokemonInActiveBench()) {
            printingString("no active pokemon");
            return 0;
        }
        if (currecntSide.getActive0() != null) {
            if (currecntSide.getActive0().getCardName().equals("ducklett") ||
                    currecntSide.getActive0().getCardName().equals("rowlet")) {
                printingString("invalid action");
                return 0;
            }
            if ((currecntSide.getActive0().getCardName().equals("dragonite") || currecntSide.getActive0().getCardName().equals("tepig") || currecntSide.getActive0().getCardName().equals("lugia"))
                    && !doWeHaveAnyPokemonThere(String.valueOf(0))) {
                printingString("no pokemon in the selected place");
                return 0;
            }
            if (currecntSide.getActive0().isAsleep()) {
                printingString("active pokemon is sleeping");

                return 0;
            }
            if (currecntSide.getActive0().getCardName().equals("dragonite")) {
                dragoniteCardAction();
                printingString("action executed successfully");
                return 1;
            }
            if (currecntSide.getActive0().getCardName().equals("tepig")) {
                tepigCardAction();
                printingString("action executed successfully");
                return 1;
            }
            if (currecntSide.getActive0().getCardName().equals("lugia")) {
                lugiaCardAction();
                printingString("action executed successfully");
                return 1;
            }
            if (currecntSide.getActive0().getCardName().equals("pineco")) {
                pinecoCardAction();
                printingString("action executed successfully");
                return 1;
            }
        }
        return 0;
    }

    private static int executeActionWithTarget(String input) {
        String regex = "execute\\s+action\\s+-t\\s+(?<target>.*)";
        Matcher matcher = getCommandMatcher(input.trim(), regex);
        if (matcher.matches()) {
            String target = matcher.group("target");
            if (!doIHaveAnyPokemonInActiveBench()) {
                printingString("no active pokemon");
                return 0;
            }
            if (currecntSide.getActive0() != null) {
                if (!currecntSide.getActive0().getCardName().equals("ducklett") &&
                        !currecntSide.getActive0().getCardName().equals("rowlet")) {
                    printingString("invalid action");
                    return 0;
                }
                if (currecntSide.getActive0().getCardName().equals("ducklett")) {
                    if (!target.equals("0") && !target.equals("1") && !target.equals("2") && !target.equals("3")) {
                        printingString("invalid target number");
                        return 0;
                    }
                }
                if (currecntSide.getActive0().getCardName().equals("rowlet")) {
                    if (!target.equals("1") && !target.equals("2") && !target.equals("3")) {
                        printingString("invalid target number");
                        return 0;
                    }
                }

                if (!doWeHaveAnyPokemonHere(target) &&
                        currecntSide.getActive0().getCardName().equals("rowlet")) {
                    printingString("no pokemon in the selected place");
                    return 0;
                }
                if (!doWeHaveAnyPokemonThere(target) &&
                        currecntSide.getActive0().getCardName().equals("ducklett")) {
                    printingString("no pokemon in the selected place");
                    return 0;
                }
                if (currecntSide.getActive0().isAsleep()) {
                    printingString("active pokemon is sleeping");

                    return 0;
                }
                if (currecntSide.getActive0().getCardName().equals("ducklett")) {
                    duclletCardAction(target);
                    printingString("action executed successfully");
                    return 1;
                }
                if (currecntSide.getActive0().getCardName().equals("rowlet")) {
                    rowletCardAction(target);
                    printingString("action executed successfully");
                    return 1;
                }
            }
        }
        return 0;
    }

    private static void rowletCardAction(String target) {
        double energ1 = 1;
        double energy2 = 1;
        boolean e1 = false;
        boolean e2 = false;
        if (currecntSide.getActive0() != null) {
            ArrayList<Energy> energy = currecntSide.getActive0().getEnergyCards();
            if (energy != null && energy.size() >= 1 && energy != null) {
                if (energy.get(0) != null) {
                    energ1 = energy.get(0).getEnergy(currecntSide.getActive0().getType());
                    e1 = true;
                }
            }
            if (energy != null && energy.size() >= 2 && energy != null) {
                if (energy.get(1) != null) {
                    energy2 = energy.get(1).getEnergy(currecntSide.getActive0().getType());
                    e2 = true;
                }
            }
            if (e1 && e2) {
                if (energy != null && energy.size() >= 2) {
                    Energy energy3 = energy.get(1);
                    ArrayList<Energy> energy1 = new ArrayList<>();
                    energy1.add(energy3);
                    currecntSide.getActive0().setCompeleteEnergy(energy1);
                }

            } else if (e1 && !e2) {

                ArrayList<Energy> energy1 = new ArrayList<>();
                currecntSide.getActive0().setCompeleteEnergy(energy1);
                currecntSide.getActive0().setCompeleteEnergy(null);

            }


            double heal = returningHealForRowlet(target, energ1, energy2);
            settingHealForRowlet(target, heal);

        }
    }

    private static void settingHealForRowlet(String target, double heal) {
        if (target.equals("1")) {
            settingHealForBench1(heal);
        }
        if (target.equals("2")) {
            settingHealForBench2(heal);
        }
        if (target.equals("3")) {
            settingHealForBench3(heal);
        }
    }

    private static void settingHealForBench3(double heal) {
        if (currecntSide.getBench3() != null) {
            currecntSide.getBench3().setRemainingHitPoint(heal);
            if (currecntSide.getBench3().getIsBurning() && currecntSide.getBench3().getType().equals("fire")) {
                currecntSide.getBench3().setRemainingHitPoint(-10);
                currecntSide.getBench3().setBurning(false);
            }
            if (currecntSide.getBench3().getRemainingHitPoint() > currecntSide.getBench3().getMaxHitPoint())
                currecntSide.getBench3().setRemainingHitPoint(currecntSide.getBench3().getMaxHitPoint() - currecntSide.getBench3().getRemainingHitPoint());
            if (currecntSide.getBench3().getRemainingHitPoint() <= 0) {
                double makeItZero = currecntSide.getBench3().getRemainingHitPoint();
                currecntSide.getBench3().setRemainingHitPoint(-makeItZero);
                notCurrentUser.setReduce(currecntSide.getBench3().getMaxHitPoint());
                currecntSide.setBench3(null);
            }
        }
    }

    private static void settingHealForBench1(double heal) {
        if (currecntSide.getBench1() != null) {
            currecntSide.getBench1().setRemainingHitPoint(heal);
            if (currecntSide.getBench1().getIsBurning() && currecntSide.getBench1().getType().equals("fire")) {
                currecntSide.getActive0().setRemainingHitPoint(-10);
                currecntSide.getActive0().setBurning(false);
            }
            if (currecntSide.getBench1().getRemainingHitPoint() > currecntSide.getBench1().getMaxHitPoint())
                currecntSide.getBench1().setRemainingHitPoint(currecntSide.getBench1().getMaxHitPoint() - currecntSide.getBench1().getRemainingHitPoint());
            if (currecntSide.getActive0().getRemainingHitPoint() <= 0) {
                double makeItZero = currecntSide.getActive0().getRemainingHitPoint();
                currecntSide.getActive0().setRemainingHitPoint(-makeItZero);
                notCurrentUser.setReduce(currecntSide.getActive0().getMaxHitPoint());
                currecntSide.setActive0(null);
            }
        }
    }

    private static void settingHealForBench2(double heal) {
        if (currecntSide.getBench2() != null) {
            currecntSide.getBench2().setRemainingHitPoint(heal);
            if (currecntSide.getBench2().getIsBurning() && currecntSide.getBench2().getType().equals("fire")) {
                currecntSide.getBench2().setRemainingHitPoint(-10);
                currecntSide.getBench2().setBurning(false);
            }
            if (currecntSide.getBench2().getRemainingHitPoint() > currecntSide.getBench2().getMaxHitPoint())
                currecntSide.getBench2().setRemainingHitPoint(currecntSide.getBench2().getMaxHitPoint() - currecntSide.getBench2().getRemainingHitPoint());
            if (currecntSide.getBench2().getRemainingHitPoint() <= 0) {
                double makeItZero = currecntSide.getBench2().getRemainingHitPoint();
                currecntSide.getBench2().setRemainingHitPoint(-makeItZero);
                notCurrentUser.setReduce(currecntSide.getBench2().getMaxHitPoint());
                currecntSide.setBench2(null);
            }
        }
    }

    private static double returningHealForRowlet(String target, double energ1, double energy2) {
        double heal = 0;
        if (target.equals("1")) {
            if (currecntSide.getActive0() != null && currecntSide.getBench1() != null) {
                heal = currecntSide.getActive0().getPower() * energ1 * energy2 *
                        currecntSide.getBench1().getWeakness(currecntSide.getActive0().getType()) *
                        currecntSide.getBench1().getResistance();

            }
        }
        if (target.equals("2")) {
            if (currecntSide.getActive0() != null && currecntSide.getBench2() != null) {
                heal = currecntSide.getActive0().getPower() * energ1 * energy2 *
                        currecntSide.getBench2().getWeakness(currecntSide.getActive0().getType()) *
                        currecntSide.getBench2().getResistance();

            }
        }
        if (target.equals("3")) {
            if (currecntSide.getActive0() != null && currecntSide.getBench3() != null) {
                heal = currecntSide.getActive0().getPower() * energ1 * energy2 *
                        currecntSide.getBench3().getWeakness(currecntSide.getActive0().getType()) *
                        currecntSide.getBench3().getResistance();

            }
        }
        return heal;
    }

    private static void pinecoCardAction() {
        double energ1 = 1;
        double energy2 = 1;
        boolean e1 = false;
        boolean e2 = false;
        if (currecntSide.getActive0() != null) {
            ArrayList<Energy> energy = currecntSide.getActive0().getEnergyCards();
            if (energy.size() >= 1) {
                if (energy.get(0) != null) {
                    energ1 = energy.get(0).getEnergy(currecntSide.getActive0().getType());
                    e1 = true;
                }
            }
            if (energy.size() >= 2) {
                if (energy.get(1) != null) {
                    energy2 = energy.get(1).getEnergy(currecntSide.getActive0().getType());
                    e2 = true;
                }
            }
            if (e1 && e2) {
                Energy energy3 = energy.get(1);
                ArrayList<Energy> energy1 = new ArrayList<>();
                energy1.add(energy3);
                currecntSide.getActive0().setCompeleteEnergy(energy1);
            } else if (e1 && !e2) {

                ArrayList<Energy> energy1 = new ArrayList<>();
                currecntSide.getActive0().setCompeleteEnergy(energy1);
            }
            double heal = currecntSide.getActive0().getPower() * energ1 * energy2 *
                    currecntSide.getActive0().getWeakness(currecntSide.getActive0().getType()) *
                    currecntSide.getActive0().getResistance();
            currecntSide.getActive0().setRemainingHitPoint(heal);
            if (currecntSide.getActive0().getIsBurning() && currecntSide.getActive0().getType().equals("fire")) {
                currecntSide.getActive0().setRemainingHitPoint(-10);
                currecntSide.getActive0().setBurning(false);
            }
            if (currecntSide.getActive0().getRemainingHitPoint() <= 0) {
                double makeItZero = currecntSide.getActive0().getRemainingHitPoint();
                currecntSide.getActive0().setRemainingHitPoint(-makeItZero);
                notCurrentUser.setReduce(currecntSide.getActive0().getMaxHitPoint());
                currecntSide.setActive0(null);
            }

            if (currecntSide.getActive0().getRemainingHitPoint() > currecntSide.getActive0().getMaxHitPoint())
                currecntSide.getActive0().setRemainingHitPoint(-currecntSide.getActive0().getRemainingHitPoint() + currecntSide.getActive0().getMaxHitPoint());
        }
    }

    private static void duclletCardAction(String target) {
        boolean e1 = false;
        boolean e2 = false;
        Pokemon pokemon = returnWichPokemonShouldBeDamaged(target);
        ArrayList<Energy> energy1 = new ArrayList<>();
        pokemon.setCompeleteEnergy(energy1);
        double energ1 = 1;
        double energy2 = 1;
        if (currecntSide.getActive0() != null) {
            ArrayList<Energy> energy = currecntSide.getActive0().getEnergyCards();
            if (energy.size() >= 1) {
                if (energy.get(0) != null) {
                    energ1 = energy.get(0).getEnergy(currecntSide.getActive0().getType());
                    e1 = true;
                }
            }
            if (energy.size() >= 2) {
                if (energy.get(1) != null) {
                    energy2 = energy.get(1).getEnergy(currecntSide.getActive0().getType());
                    e2 = true;
                }
            }
            if (e1 && e2) {
                if (energy.size() >= 2) {
                    Energy energy3 = energy.get(1);
                    ArrayList<Energy> energy4 = new ArrayList<>();
                    energy4.add(energy3);
                    currecntSide.getActive0().setCompeleteEnergy(energy4);
                }
            } else if (e1 && !e2) {
                ArrayList<Energy> energy4 = new ArrayList<>();
                currecntSide.getActive0().setCompeleteEnergy(energy4);
            }
            if (pokemon != null && currecntSide.getActive0() != null) {
                double damage = (-1) * currecntSide.getActive0().getPower() * energ1 * energy2 *
                        pokemon.getWeakness(currecntSide.getActive0().getType()) *
                        pokemon.getResistance();
                if (pokemon.getCardName().equals("pineco") || pokemon.getCardName().equals("rowlet")) {
                    if (damage >= -15) damage = 0;
                    else damage += 15;
                }
                pokemon.setRemainingHitPoint(damage);
                if (pokemon.getRemainingHitPoint() <= 0) {
                    pokemon.setRemainingHitPoint(-pokemon.getRemainingHitPoint());
                    currentUser.setReduce(pokemon.getMaxHitPoint());
                    if (target.equals("0")) {
                        if (notCurrentSide.getActive0() != null) {
                            notCurrentSide.setActive0(null);
                        }
                    }
                    if (target.equals("1")) {
                        if (notCurrentSide.getBench1() != null) {
                            notCurrentSide.setBench1(null);
                        }
                    }
                    if (target.equals("2")) {
                        if (notCurrentSide.getBench2() != null) {
                            notCurrentSide.setBench2(null);
                        }
                    }
                    if (target.equals("3")) {
                        if (notCurrentSide.getBench3() != null) {
                            notCurrentSide.setBench3(null);
                        }
                    }
                }
            }
        }
    }

    private static Pokemon returnWichPokemonShouldBeDamaged(String target) {
        if (target.equals("0")) return notCurrentSide.getActive0();
        if (target.equals("1")) return notCurrentSide.getBench1();
        if (target.equals("2")) return notCurrentSide.getBench2();
        if (target.equals("3")) return notCurrentSide.getBench3();
        return null;
    }

    private static void lugiaCardAction() {
        if (notCurrentSide.getActive0() != null)
            notCurrentSide.getActive0().setAsleep(true);
        double energ1 = 1;
        double energy2 = 1;
        boolean e1 = false;
        boolean e2 = false;
        if (currecntSide.getActive0() != null) {
            ArrayList<Energy> energy = currecntSide.getActive0().getEnergyCards();
            if (energy != null) {
                if (energy.size() >= 1) {
                    if (energy.get(0) != null) {
                        energ1 = energy.get(0).getEnergy(currecntSide.getActive0().getType());
                        e1 = true;
                    }
                }
            }
            if (energy != null) {
                if (energy.size() >= 2) {
                    if (energy.get(1) != null) {
                        energy2 = energy.get(1).getEnergy(currecntSide.getActive0().getType());
                        e2 = true;
                    }
                }
            }
            if (e1 && e2) {
                if (energy.size() >= 2) {
                    Energy energy3 = energy.get(1);
                    ArrayList<Energy> energy1 = new ArrayList<>();
                    energy1.add(energy3);
                    currecntSide.getActive0().setCompeleteEnergy(energy1);
                }

            } else if (e1 && !e2) {
                ArrayList<Energy> energy1 = new ArrayList<>();
                currecntSide.getActive0().setCompeleteEnergy(energy1);
            }

            double damage = (-1) * currecntSide.getActive0().getPower() * energ1 * energy2 *
                    notCurrentSide.getActive0().getWeakness(currecntSide.getActive0().getType()) *
                    notCurrentSide.getActive0().getResistance();
            if (notCurrentSide.getActive0().getCardName().equals("pineco") || notCurrentSide.getActive0().getCardName().equals("rowlet")) {
                if (damage >= -15) damage = 0;
                else damage += 15;
            }
            notCurrentSide.getActive0().setRemainingHitPoint(damage);
            if (notCurrentSide.getActive0().getRemainingHitPoint() <= 0) {
                double makeItZero = notCurrentSide.getActive0().getRemainingHitPoint();
                notCurrentSide.getActive0().setRemainingHitPoint(-makeItZero);
                currentUser.setReduce(notCurrentSide.getActive0().getMaxHitPoint());
                notCurrentSide.setActive0(null);
            }
        }
    }

    private static void tepigCardChangingMode() {
        if (notCurrentSide.getActive0() != null &&
                !notCurrentSide.getActive0().getType().equals("water"))
            notCurrentSide.getActive0().setBurning(true);
        if (notCurrentSide.getBench1() != null &&
                !notCurrentSide.getBench1().getType().equals("water"))
            notCurrentSide.getBench1().setBurning(true);
        if (notCurrentSide.getBench2() != null &&
                !notCurrentSide.getBench2().getType().equals("water"))
            notCurrentSide.getBench2().setBurning(true);
        if (notCurrentSide.getBench3() != null &&
                !notCurrentSide.getBench3().getType().equals("water"))
            notCurrentSide.getBench3().setBurning(true);
    }

    private static void givingDamageToActive0InTepig(double energ1, double energy2) {
        if (notCurrentSide.getActive0() != null) {
            double damage = (-1) * currecntSide.getActive0().getPower() * energ1 * energy2 *
                    notCurrentSide.getActive0().getWeakness(currecntSide.getActive0().getType()) *
                    notCurrentSide.getActive0().getResistance();
            if (notCurrentSide.getActive0().getCardName().equals("pineco") || notCurrentSide.getActive0().getCardName().equals("rowlet")) {
                if (damage >= -15) {
                    damage = 0;
                } else damage += 15;
            }
            notCurrentSide.getActive0().setRemainingHitPoint(damage);
            if (notCurrentSide.getActive0().getRemainingHitPoint() <= 0) {
                double makeItZero = notCurrentSide.getActive0().getRemainingHitPoint();
                notCurrentSide.getActive0().setRemainingHitPoint(-makeItZero);
                currentUser.setReduce(notCurrentSide.getActive0().getMaxHitPoint());
                notCurrentSide.setActive0(null);
            }
        }
    }

    private static void givingDamageToBench1(double energ1, double energy2) {
        if (notCurrentSide.getBench1() != null && currecntSide.getActive0() != null) {
            double damage = (-0.2) * currecntSide.getActive0().getPower() * energ1 * energy2 *
                    notCurrentSide.getBench1().getWeakness(currecntSide.getActive0().getType()) *
                    notCurrentSide.getBench1().getResistance();
            if (notCurrentSide.getBench1().getCardName().equals("pineco") || notCurrentSide.getBench1().getCardName().equals("rowlet")) {
                if (damage >= -15) damage = 0;
                else damage += 15;
            }
            notCurrentSide.getBench1().setRemainingHitPoint(damage);
            if (notCurrentSide.getBench1().getRemainingHitPoint() <= 0) {
                double makeItZero = notCurrentSide.getBench1().getRemainingHitPoint();
                notCurrentSide.getBench1().setRemainingHitPoint(-makeItZero);
                currentUser.setReduce(notCurrentSide.getBench1().getMaxHitPoint());
                notCurrentSide.setBench1(null);
            }
        }
    }

    private static void givingDamageToBench2(double energ1, double energy2) {
        if (notCurrentSide.getBench2() != null && currecntSide.getActive0() != null) {
            double damage = (-0.2) * currecntSide.getActive0().getPower() * energ1 * energy2 *
                    notCurrentSide.getBench2().getWeakness(currecntSide.getActive0().getType()) *
                    notCurrentSide.getBench2().getResistance();
            if (notCurrentSide.getBench2().getCardName().equals("pineco") || notCurrentSide.getBench2().getCardName().equals("rowlet")) {
                if (damage >= -15) damage = 0;
                else damage += 15;
            }
            notCurrentSide.getBench2().setRemainingHitPoint(damage);
            if (notCurrentSide.getBench2().getRemainingHitPoint() <= 0) {
                double makeItZero = notCurrentSide.getBench2().getRemainingHitPoint();
                notCurrentSide.getBench2().setRemainingHitPoint(-makeItZero);
                currentUser.setReduce(notCurrentSide.getBench2().getMaxHitPoint());
                notCurrentSide.setBench2(null);
            }
        }
    }

    private static void givingDamageToBench3(double energ1, double energy2) {
        if (notCurrentSide.getBench3() != null && currecntSide.getActive0() != null) {

            double damage = (-0.2) * currecntSide.getActive0().getPower() * energ1 * energy2 *
                    notCurrentSide.getBench3().getWeakness(currecntSide.getActive0().getType()) *
                    notCurrentSide.getBench3().getResistance();
            if (notCurrentSide.getBench3().getCardName().equals("pineco") || notCurrentSide.getBench3().getCardName().equals("rowlet")) {
                if (damage >= -15) damage = 0;
                else damage += 15;
            }
            notCurrentSide.getBench3().setRemainingHitPoint(damage);
            if (notCurrentSide.getBench3().getRemainingHitPoint() <= 0) {
                double makeItZero = notCurrentSide.getBench3().getRemainingHitPoint();
                notCurrentSide.getBench3().setRemainingHitPoint(-makeItZero);
                currentUser.setReduce(notCurrentSide.getBench3().getMaxHitPoint());
                notCurrentSide.setBench3(null);

            }
        }
    }

    private static void tepigCardAction() {
        tepigCardChangingMode();
        double energ1 = 1;
        double energy2 = 1;
        boolean e1 = false;
        boolean e2 = false;
        if (currecntSide.getActive0() != null && notCurrentSide.getActive0() != null) {
            ArrayList<Energy> energy = currecntSide.getActive0().getEnergyCards();
            if (energy.size() >= 1) {
                if (energy.get(0) != null) {
                    energ1 = energy.get(0).getEnergy(currecntSide.getActive0().getType());
                    e1 = true;

                }
            }
            if (energy.size() >= 2) {
                if (energy.get(1) != null) {
                    energy2 = energy.get(1).getEnergy(currecntSide.getActive0().getType());
                    e2 = true;

                }
            }
            if (e1 && e2) {
                if (energy.size() >= 2) {
                    Energy energy3 = energy.get(1);
                    ArrayList<Energy> energy1 = new ArrayList<>();
                    energy1.add(energy3);
                    currecntSide.getActive0().setCompeleteEnergy(energy1);
                }

            } else if (e1 && !e2) {
                ArrayList<Energy> energy1 = new ArrayList<>();
                currecntSide.getActive0().setCompeleteEnergy(energy1);
            }
            givingDamageToActive0InTepig(energ1, energy2);
        }
        givingDamageToBench1(energ1, energy2);
        givingDamageToBench2(energ1, energy2);
        givingDamageToBench3(energ1, energy2);
    }


    private static void dragoniteCardAction() {
        if (notCurrentSide.getActive0() != null && !notCurrentSide.getActive0().getType().equals("water"))
            notCurrentSide.getActive0().setBurning(true);
        double energ1 = 1;
        double energy2 = 1;
        boolean e1 = false;
        boolean e2 = false;
        ArrayList<Energy> energy = currecntSide.getActive0().getEnergyCards();
        if (energy.size() >= 1) {
            if (energy.get(0) != null) {
                energ1 = energy.get(0).getEnergy(currecntSide.getActive0().getType());
                e1 = true;
            }
        }
        if (energy.size() >= 2) {
            if (energy.get(1) != null) {
                energy2 = energy.get(1).getEnergy(currecntSide.getActive0().getType());
                e2 = true;
            }
        }
        if (e1 && e2) {
            if (energy.size() >= 2) {
                Energy energy3 = energy.get(1);
                ArrayList<Energy> energy1 = new ArrayList<>();
                energy1.add(energy3);

                currecntSide.getActive0().setCompeleteEnergy(energy1);
            }

        } else if (e1 && !e2) {
            if (energy.size() >= 2) {
                Energy energy3 = energy.get(1);
                ArrayList<Energy> energy1 = new ArrayList<>();
                energy1.add(energy3);
                currecntSide.getActive0().setCompeleteEnergy(energy1);

            } else {
                ArrayList<Energy> energy1 = new ArrayList<>();
                currecntSide.getActive0().setCompeleteEnergy(energy1);
            }

        } else if (e2 && !e1) {
            ArrayList<Energy> energy1 = new ArrayList<>();
            currecntSide.getActive0().setCompeleteEnergy(energy1);
        }
        givingDamageForDraginite(energ1, energy2);

    }

    private static void givingDamageForDraginite(double energ1, double energy2) {
        if (notCurrentSide.getActive0() != null) {

            double damage = (-1) * currecntSide.getActive0().getPower() * energ1 * energy2 *
                    notCurrentSide.getActive0().getWeakness(currecntSide.getActive0().getType()) *
                    notCurrentSide.getActive0().getResistance();
            if (notCurrentSide.getActive0().getCardName().equals("pineco") || notCurrentSide.getActive0().getCardName().equals("rowlet")) {
                if (damage >= -15) damage = 0;
                else damage += 15;
            }
            notCurrentSide.getActive0().setRemainingHitPoint(damage);
            if (notCurrentSide.getActive0().getRemainingHitPoint() <= 0) {
                double toMakeItZero = notCurrentSide.getActive0().getRemainingHitPoint();
                notCurrentSide.getActive0().setRemainingHitPoint(-toMakeItZero);
                currentUser.setReduce(notCurrentSide.getActive0().getMaxHitPoint());
                notCurrentSide.setActive0(null);


            }
        }
    }

    public static void eachCardForItsSelfBurning() {
        if (currecntSide.getActive0() != null) {
            if (!currecntSide.getActive0().getCardName().equals("lugia") && !currecntSide.getActive0().getCardName().equals("ducklett")
                    && !currecntSide.getActive0().getCardName().equals("pineco") && !currecntSide.getActive0().getCardName().equals("rowlet")) {
                if (currecntSide.getActive0().getIsBurning()) {
                    currecntSide.getActive0().setRemainingHitPoint(-10);
                    currecntSide.getActive0().setBurning(false);
                    if (currecntSide.getActive0().getRemainingHitPoint() <= 0) {
                        double makeItZero = currecntSide.getActive0().getRemainingHitPoint();
                        currecntSide.getActive0().setRemainingHitPoint(-makeItZero);
                        notCurrentUser.setReduce(currecntSide.getActive0().getMaxHitPoint());
                        currecntSide.setActive0(null);
                    }
                }
            }
        } else currecntSide.getActive0().setBurning(false);
        if (currecntSide.getBench1() != null) {
            if (!currecntSide.getBench1().getCardName().equals("lugia") && !currecntSide.getBench1().getCardName().equals("ducklett")
                    && !currecntSide.getBench1().getCardName().equals("pineco") && !currecntSide.getBench1().getCardName().equals("rowlet")) {
                if (currecntSide.getBench1().getIsBurning()) {
                    currecntSide.getBench1().setRemainingHitPoint(-10);
                    currecntSide.getBench1().setBurning(false);
                    if (currecntSide.getBench1().getRemainingHitPoint() <= 0) {
                        double makeItZero = currecntSide.getBench1().getRemainingHitPoint();
                        currecntSide.getBench1().setRemainingHitPoint(-makeItZero);
                        notCurrentUser.setReduce(currecntSide.getBench1().getMaxHitPoint());
                        currecntSide.setBench1(null);

                    }
                }
            }
        } else if (currecntSide.getBench1() != null) currecntSide.getBench1().setBurning(false);
        if (currecntSide.getBench2() != null) {
            if (!currecntSide.getBench2().getCardName().equals("lugia") && !currecntSide.getBench2().getCardName().equals("ducklett")
                    && !currecntSide.getBench2().getCardName().equals("pineco") && !currecntSide.getBench2().getCardName().equals("rowlet")) {
                if (currecntSide.getBench2().getIsBurning()) {
                    currecntSide.getBench2().setRemainingHitPoint(-10);
                    currecntSide.getBench2().setBurning(false);
                    if (currecntSide.getBench2().getRemainingHitPoint() <= 0) {
                        double makeItZero = currecntSide.getBench2().getRemainingHitPoint();
                        currecntSide.getBench2().setRemainingHitPoint(-makeItZero);
                        notCurrentUser.setReduce(currecntSide.getBench2().getMaxHitPoint());
                        currecntSide.setBench2(null);

                    }
                }
            }
        } else if (currecntSide.getBench2() != null) currecntSide.getBench2().setBurning(false);
        if (currecntSide.getBench3() != null) {
            if (!currecntSide.getBench3().getCardName().equals("lugia") && !currecntSide.getBench3().getCardName().equals("ducklett")
                    && !currecntSide.getBench3().getCardName().equals("pineco") && !currecntSide.getBench3().getCardName().equals("rowlet")) {
                if (currecntSide.getBench3().getIsBurning()) {
                    currecntSide.getBench3().setRemainingHitPoint(-10);
                    currecntSide.getBench3().setBurning(false);
                    if (currecntSide.getBench3().getRemainingHitPoint() <= 0) {
                        double makeItZero = currecntSide.getBench3().getRemainingHitPoint();
                        currecntSide.getBench3().setRemainingHitPoint(-makeItZero);
                        notCurrentUser.setReduce(currecntSide.getBench3().getMaxHitPoint());
                        currecntSide.setBench3(null);
                    }
                }
            }
        } else if (currecntSide.getBench3() != null) currecntSide.getBench3().setBurning(false);
    }

    public static void calculateExpAndCoin(User user) {
        user.setExperience(user.getExperience() + (user.getKilled() * 10));
        user.setCoin(user.getCoin() + ((int) user.getReduce() / 10));
    }

    public static boolean doIHaveAnyPokemonInActiveBench() {
        if (currecntSide.getActive0() == null) return false;
        return true;
    }

    private static Matcher getCommandMatcher(String input, String regex) {
        Pattern pattern = Pattern.compile(regex);

        return pattern.matcher(input);
    }

    public static void swapingThings(User user1, User user2, Side side1, Side side2) {
        boolean isAdded = true;
        if (currentUser.equals(user1)) {
            currentUser = user2;
            notCurrentUser = user1;
            currecntSide = side2;
            notCurrentSide = side1;
            putEnergy = 0;
            isAdded = false;
        } else if (currentUser.equals(user2) && isAdded) {

            currentUser = user1;
            notCurrentUser = user2;
            currecntSide = side1;
            notCurrentSide = side2;
            putEnergy = 0;
            round++;
        }
    }

    public static void putCard(Matcher matcher, User user) {

        if (matcher.matches()) {
            String cardName = matcher.group("cardname");
            String placeNumber = matcher.group("placenumber");

            int eror = 0;
            if (!isCardValid(cardName)) {
                printingString("card name is invalid");
                eror = 1;
            }
            if (eror == 0 && !doWeHaveThisCard(user, cardName)) {
                printingString("you don't have the selected card");
                eror = 1;
            }
            if (eror == 0 && !placeNumber.equals("0") && !placeNumber.equals("1") && !placeNumber.equals("2") && !placeNumber.equals("3")) {
                printingString("invalid place number");
                eror = 1;
            }
            if (eror == 0 && isPokemon(cardName) && ThatBenchNull(placeNumber) != null) {
                printingString("a pokemon already exists there");
                eror = 1;
            }
            if (eror == 0 && !isPokemon(cardName) && ThatBenchNull(placeNumber) == null) {
                printingString("no pokemon in the selected place");
                eror = 1;
            }
            if (eror == 0 && !isPokemon(cardName) && ThatBenchEnergy(placeNumber) == 2) {
                printingString("pokemon already has 2 energies");
                eror = 1;
            }
            if (eror == 0 && !isPokemon(cardName) && putEnergy == 1) {
                printingString("you have already played an energy card in this turn");
                eror = 1;
            }
            if (eror == 0) {
                printingString("card put successful");

                if (isPokemon(cardName))
                    fillingPokemonInSide(placeNumber, cardName);

                else {
                    fillingEnergyCardInSide(placeNumber, cardName);
                    putEnergy = 1;
                }
            }


        }
    }

    private static boolean isCardValid(String cardName) {
        if ((cardName.equals("dragonite")) || (cardName.equals("tepig")) ||
                (cardName.equals("lugia")) || (cardName.equals("ducklett")) ||
                (cardName.equals("pineco")) || (cardName.equals("rowlet")) ||
                (cardName.equals("pink")) || (cardName.equals("yellow"))) {
            return true;
        }
        return false;
    }

    private static boolean doWeHaveThisCard(User user, String cardname) {
        ArrayList<Cards> cards = user.getDeckCards();
        for (int i = 0; i < cards.size(); i++) {
            if (cards.get(i).getCardName().equals(cardname)) return true;
        }
        return false;
    }

    private static boolean isPokemon(String name) {
        if (name.equals("dragonite") || name.equals("tepig") || name.equals("lugia") || name.equals("ducklett")
                || name.equals("pineco") || name.equals("rowlet")) {
            return true;
        }
        return false;
    }

    private static Pokemon ThatBenchNull(String placeNumber) {

        if (placeNumber.equals("0")) return currecntSide.getActive0();
        if (placeNumber.equals("1")) return currecntSide.getBench1();
        if (placeNumber.equals("2")) return currecntSide.getBench2();
        if (placeNumber.equals("3")) return currecntSide.getBench3();
        return null;
    }

    private static int ThatBenchEnergy(String placeNumber) {
        if (placeNumber.equals("0") && currecntSide.getActive0().getEnergyCards() != null)
            return currecntSide.getActive0().getEnergyCards().size();
        if (placeNumber.equals("1") && currecntSide.getBench1().getEnergyCards() != null)
            return currecntSide.getBench1().getEnergyCards().size();
        if (placeNumber.equals("2") && currecntSide.getBench2().getEnergyCards() != null)
            return currecntSide.getBench2().getEnergyCards().size();
        if (placeNumber.equals("3") && currecntSide.getBench3().getEnergyCards() != null)
            return currecntSide.getBench3().getEnergyCards().size();
        return 0;
    }

    private static void fillingPokemonInSide(String placeNumber, String card) {
        if (placeNumber.equals("0")) {
            if (currentUser.getCardBynameInDeckCards(card) != null) {
                currecntSide.setActive0((Pokemon) currentUser.getCardBynameInDeckCards(card));
                currentUser.deleteCards(currentUser.getCardBynameInDeckCards(card));
                currentUser.deleteDeckCards(currentUser.getCardBynameInDeckCards(card));
            }
        }
        if (placeNumber.equals("1")) {
            if (currentUser.getCardBynameInDeckCards(card) != null) {
                currecntSide.setBench1((Pokemon) currentUser.getCardBynameInDeckCards(card));
                currentUser.deleteCards(currentUser.getCardBynameInDeckCards(card));
                currentUser.deleteDeckCards(currentUser.getCardBynameInDeckCards(card));
            }
        }
        if (placeNumber.equals("2")) {
            if (currentUser.getCardBynameInDeckCards(card) != null) {
                currecntSide.setBench2((Pokemon) currentUser.getCardBynameInDeckCards(card));
                currentUser.deleteCards(currentUser.getCardBynameInDeckCards(card));
                currentUser.deleteDeckCards(currentUser.getCardBynameInDeckCards(card));
            }
        }
        if (placeNumber.equals("3")) {
            if (currentUser.getCardBynameInDeckCards(card) != null) {
                currecntSide.setBench3((Pokemon) currentUser.getCardBynameInDeckCards(card));
                currentUser.deleteCards(currentUser.getCardBynameInDeckCards(card));
                currentUser.deleteDeckCards(currentUser.getCardBynameInDeckCards(card));
            }
        }
    }

    private static void fillingEnergyCardInSide(String placeNumber, String card) {
        if (placeNumber.equals("0")) {
            if (currentUser.getCardBynameInDeckCards(card) != null) {
                currecntSide.setEnergyFor0((Energy) currentUser.getCardBynameInDeckCards(card));
                assiginingEnergyToEnergyCards((Energy) currentUser.getCardBynameInDeckCards(card));
                currentUser.deleteCards(currentUser.getCardBynameInDeckCards(card));
                currentUser.deleteDeckCards(currentUser.getCardBynameInDeckCards(card));
            }
        }
        if (placeNumber.equals("1")) {
            if (currentUser.getCardBynameInDeckCards(card) != null) {
                currecntSide.setEnergyFor1((Energy) currentUser.getCardBynameInDeckCards(card));
                assiginingEnergyToEnergyCards((Energy) currentUser.getCardBynameInDeckCards(card));
                currentUser.deleteCards(currentUser.getCardBynameInDeckCards(card));
                currentUser.deleteDeckCards(currentUser.getCardBynameInDeckCards(card));
            }
        }
        if (placeNumber.equals("2")) {
            if (currentUser.getCardBynameInDeckCards(card) != null) {
                currecntSide.setEnergyFor2((Energy) currentUser.getCardBynameInDeckCards(card));
                assiginingEnergyToEnergyCards((Energy) currentUser.getCardBynameInDeckCards(card));
                currentUser.deleteCards(currentUser.getCardBynameInDeckCards(card));
                currentUser.deleteDeckCards(currentUser.getCardBynameInDeckCards(card));
            }
        }
        if (placeNumber.equals("3")) {
            if (currentUser.getCardBynameInDeckCards(card) != null) {
                currecntSide.setEnergyFor3((Energy) currentUser.getCardBynameInDeckCards(card));
                assiginingEnergyToEnergyCards((Energy) currentUser.getCardBynameInDeckCards(card));
                currentUser.deleteCards(currentUser.getCardBynameInDeckCards(card));
                currentUser.deleteDeckCards(currentUser.getCardBynameInDeckCards(card));
            }
        }

    }

    private static void assiginingEnergyToEnergyCards(Energy energy) {
        if (energy.getCardName().equals("yellow")) {
            energy.setEnergy(1, 1.2, 1.2);
        }
        if (energy.getCardName().equals("pink")) {
            energy.setEnergy(1, 1.05, 1.15);
        }
    }

    public static void showingTable() {
        StringBuilder result = new StringBuilder();
        result.append("round " + round + "\n");
        result.append("your active card:" + "\n");
        supportShowingTable(0, result);
        result.append("\n" + "your hand:" + "\n");
        ArrayList<Cards> cards = currentUser.getDeckCards();
        int index = 1;
        for (int a = 0; a < cards.size(); a++) {
            result.append(index + "." + cards.get(a).getCardName() + "\n");
            index++;
        }
        result.append("\n" + "your bench:" + "\n");
        supportShowingTable(1, result);
        supportShowingTable(2, result);
        supportShowingTable(3, result);
        result.append("\n" + notCurrentUser.getUsername() + "'s active card:" + "\n");
        supportShowingTableForEnemy(0, result);
        result.append("\n" + notCurrentUser.getUsername() + "'s bench:" + "\n");
        supportShowingTableForEnemy(1, result);
        supportShowingTableForEnemy(2, result);
        supportShowingTableForEnemy(3, result);
        printingStringBuilder(result);
    }

    private static void supportShowingTable(int index, StringBuilder result) {
        if (currecntSide.getActive0() != null) {
            if (index == 0) {
                result.append(currecntSide.getActive0().getCardName());
                result.append("|");

                ArrayList<Energy> energy = currecntSide.getActive0().getEnergyCards();
                if (energy != null) {
                    if (energy.size() >= 1)
                        if (energy.get(0) != null) result.append(energy.get(0).getCardName());

                }
                result.append("|");
                if (energy != null) {
                    if (energy.size() >= 2)
                        if (energy.get(1) != null) result.append(energy.get(1).getCardName());
                }
                result.append("\n");
            }
        } else if (index == 0) result.append("\n");


        if (currecntSide.getBench1() != null) {
            if (index == 1) {
                result.append("1." + currecntSide.getBench1().getCardName());
                result.append("|");
                ArrayList<Energy> energy = currecntSide.getBench1().getEnergyCards();
                if (energy != null) {
                    if (energy.size() >= 1) {
                        if (energy.get(0) != null) result.append(energy.get(0).getCardName());
                    }
                }
                result.append("|");
                if (energy != null) {
                    if (energy.size() >= 2) {
                        if (energy.get(1) != null) result.append(energy.get(1).getCardName());
                    }
                }
                result.append("\n");
            }
        } else if (index == 1) result.append("1." + "\n");
        if (currecntSide.getBench2() != null) {
            if (index == 2) {
                result.append("2." + currecntSide.getBench2().getCardName());
                result.append("|");
                ArrayList<Energy> energy = currecntSide.getBench2().getEnergyCards();
                if (energy != null) {
                    if (energy.size() >= 1) {
                        if (energy.get(0) != null) result.append(energy.get(0).getCardName());
                    }
                }
                result.append("|");
                if (energy != null) {
                    if (energy.size() >= 2) {
                        if (energy.get(1) != null) result.append(energy.get(1).getCardName());
                    }
                }
                result.append("\n");
            }
        } else if (index == 2) result.append("2." + "\n");
        if (currecntSide.getBench3() != null) {
            if (index == 3) {
                result.append("3." + currecntSide.getBench3().getCardName());
                result.append("|");
                ArrayList<Energy> energy = currecntSide.getBench3().getEnergyCards();
                if (energy.size() >= 1) {
                    if (energy.get(0) != null) result.append(energy.get(0).getCardName());
                }
                result.append("|");
                if (energy.size() >= 2) {
                    if (energy.get(1) != null) result.append(energy.get(1).getCardName());
                }
                result.append("\n");
            }
        } else if (index == 3) result.append("3." + "\n");

    }

    private static void supportShowingTableForEnemy(int index, StringBuilder result) {
        if (notCurrentSide.getActive0() != null) {
            if (index == 0) {
                result.append(notCurrentSide.getActive0().getCardName());

                result.append("|");
                ArrayList<Energy> energy = notCurrentSide.getActive0().getEnergyCards();
                if (energy != null) {
                    if (energy.size() >= 1)
                        if (energy.get(0) != null) result.append(energy.get(0).getCardName());
                }
                result.append("|");
                if (energy != null) {
                    if (energy.size() >= 2)
                        if (energy.get(1) != null) result.append(energy.get(1).getCardName());
                }
                result.append("\n");
            }
        } else if (index == 0) result.append("\n");
        if (notCurrentSide.getBench1() != null) {
            if (index == 1) {
                result.append("1." + notCurrentSide.getBench1().getCardName());
                result.append("|");
                ArrayList<Energy> energy = notCurrentSide.getBench1().getEnergyCards();
                if (energy != null) {
                    if (energy.size() >= 1) {
                        if (energy.get(0) != null) result.append(energy.get(0).getCardName());
                    }
                }
                result.append("|");
                if (energy != null) {
                    if (energy.size() >= 2) {
                        if (energy.get(1) != null) result.append(energy.get(1).getCardName());
                    }
                }
                result.append("\n");
            }
        } else if (index == 1) result.append("1." + "\n");
        if (notCurrentSide.getBench2() != null) {
            if (index == 2) {
                result.append("2." + notCurrentSide.getBench2().getCardName());
                result.append("|");
                ArrayList<Energy> energy = notCurrentSide.getBench2().getEnergyCards();
                if (energy != null) {
                    if (energy.size() >= 1) {
                        if (energy.get(0) != null) result.append(energy.get(0).getCardName());
                    }
                }
                result.append("|");
                if (energy != null) {
                    if (energy.size() >= 2) {
                        if (energy.get(1) != null) result.append(energy.get(1).getCardName());
                    }
                }
                result.append("\n");
            }
        } else if (index == 2) result.append("2." + "\n");
        if (notCurrentSide.getBench3() != null) {
            if (index == 3) {
                result.append("3." + notCurrentSide.getBench3().getCardName());
                result.append("|");
                ArrayList<Energy> energy = notCurrentSide.getBench3().getEnergyCards();
                if (energy.size() >= 1) {
                    if (energy.get(0) != null) result.append(energy.get(0).getCardName());
                }
                result.append("|");
                if (energy.size() >= 2) {
                    if (energy.get(1) != null) result.append(energy.get(1).getCardName());
                }
                result.append("\n");
            }
        } else if (index == 3) result.append("3." + "\n");

    }

    public static void showMyInfo(Matcher matcher) {
        if (matcher.matches()) {
            String plceNumber = matcher.group("placenumber");
            int error = 0;
            if (!plceNumber.equals("0") && !plceNumber.equals("1") && !plceNumber.equals("2") && !plceNumber.equals("3")) {
                printingString("invalid place number");
                error = 1;
            }
            if (error == 0 && !doWeHaveAnyPokemonHere(plceNumber)) {
                printingString("no pokemon in the selected place");
                error = 1;
            }
            if (error == 0) {
                showMyInfoSupporter(plceNumber);
            }

        }

    }

    private static boolean doWeHaveAnyPokemonHere(String placeNum) {
        if (placeNum.equals("0")) {
            if (currecntSide.getActive0() == null) return false;
            else return true;
        }
        if (placeNum.equals("1")) {
            if (currecntSide.getBench1() == null) return false;
            else return true;
        }
        if (placeNum.equals("2")) {
            if (currecntSide.getBench2() == null) return false;
            else return true;
        }
        if (placeNum.equals("3")) {
            if (currecntSide.getBench3() == null) return false;
            else return true;
        }
        return false;
    }

    private static boolean doWeHaveAnyPokemonThere(String placeNum) {
        if (placeNum.equals("0")) {
            if (notCurrentSide.getActive0() == null) return false;
            else return true;
        }
        if (placeNum.equals("1")) {
            if (notCurrentSide.getBench1() == null) return false;
            else return true;
        }
        if (placeNum.equals("2")) {
            if (notCurrentSide.getBench2() == null) return false;
            else return true;
        }
        if (placeNum.equals("3")) {
            if (notCurrentSide.getBench3() == null) return false;
            else return true;
        }
        return false;
    }

    private static void showMyInfoSupporter(String placeNum) {
        StringBuilder result = new StringBuilder();
        result.append("pokemon: ");
        if (placeNum.equals("0")) {
            ArrayList<Energy> energy = currecntSide.getActive0().getEnergyCards();
            result.append(currecntSide.getActive0().getCardName() + "\n");
            result.append("special condition: ");
            if (currecntSide.getActive0().isAsleep()) result.append("sleep");
            if (currecntSide.getActive0().getIsBurning()) result.append("burning");
            result.append("\n");
            result.append("hitpoint: ");
            if (!Double.isNaN((currecntSide.getActive0().getRemainingHitPoint())) && !Double.isNaN(currecntSide.getActive0().getMaxHitPoint())) {
                result.append(String.format("%.2f", currecntSide.getActive0().getRemainingHitPoint()) + "/" + String.format("%.2f", currecntSide.getActive0().getMaxHitPoint()) + "\n");
            }
            result.append("energy 1: ");
            if (energy != null) {
                if (energy.size() >= 1) {
                    if (energy.get(0) != null)
                        result.append(energy.get(0).getCardName());
                }
            }
            result.append("\n");
            result.append("energy 2: ");
            if (energy != null) {
                if (energy.size() >= 2) {
                    if (energy.get(1) != null)
                        result.append(energy.get(1).getCardName());
                }
            }
            result.append("\n");
        }
        if (placeNum.equals("1")) {
            ArrayList<Energy> energy = currecntSide.getBench1().getEnergyCards();
            result.append(currecntSide.getBench1().getCardName() + "\n");
            result.append("special condition: ");
            if (currecntSide.getBench1().isAsleep()) result.append("sleep");
            if (currecntSide.getBench1().getIsBurning()) result.append("burning");
            result.append("\n");
            result.append("hitpoint: ");
            if (!Double.isNaN((currecntSide.getBench1().getRemainingHitPoint())) && !Double.isNaN(currecntSide.getBench1().getMaxHitPoint())) {
                result.append(String.format("%.2f", currecntSide.getBench1().getRemainingHitPoint()) + "/" + String.format("%.2f", currecntSide.getBench1().getMaxHitPoint()) + "\n");
            }
            result.append("energy 1: ");
            if (energy != null) {
                if (energy.size() >= 1) {
                    if (energy.get(0) != null)
                        result.append(energy.get(0).getCardName());
                }
            }
            result.append("\n");
            result.append("energy 2: ");
            if (energy != null) {
                if (energy.size() >= 2) {
                    if (energy.get(1) != null)
                        result.append(energy.get(1).getCardName());
                }
            }
            result.append("\n");
        }
        if (placeNum.equals("2")) {
            ArrayList<Energy> energy = currecntSide.getBench2().getEnergyCards();
            result.append(currecntSide.getBench2().getCardName() + "\n");
            result.append("special condition: ");
            if (currecntSide.getBench2().isAsleep()) result.append("sleep");
            if (currecntSide.getBench2().getIsBurning()) result.append("burning");
            result.append("\n");
            result.append("hitpoint: ");
            if (!Double.isNaN((currecntSide.getBench2().getRemainingHitPoint())) && !Double.isNaN(currecntSide.getBench2().getMaxHitPoint())) {
                result.append(String.format("%.2f", currecntSide.getBench2().getRemainingHitPoint()) + "/" + String.format("%.2f", currecntSide.getBench2().getMaxHitPoint()) + "\n");
            }
            result.append("energy 1: ");
            if (energy != null) {
                if (energy.size() >= 1) {
                    if (energy.get(0) != null)
                        result.append(energy.get(0).getCardName());
                }
            }
            result.append("\n");
            result.append("energy 2: ");
            if (energy != null) {
                if (energy.size() >= 2) {
                    if (energy.get(1) != null)
                        result.append(energy.get(1).getCardName());
                }
            }
            result.append("\n");
        }
        if (placeNum.equals("3")) {
            ArrayList<Energy> energy = currecntSide.getBench3().getEnergyCards();
            result.append(currecntSide.getBench3().getCardName() + "\n");
            result.append("special condition: ");
            if (currecntSide.getBench3().isAsleep()) result.append("sleep");
            if (currecntSide.getBench3().getIsBurning()) result.append("burning");
            result.append("\n");
            result.append("hitpoint: ");
            if (!Double.isNaN((currecntSide.getBench3().getRemainingHitPoint())) && !Double.isNaN(currecntSide.getBench3().getMaxHitPoint())) {
                result.append(String.format("%.2f", currecntSide.getBench3().getRemainingHitPoint()) + "/" + String.format("%.2f", currecntSide.getBench3().getMaxHitPoint()) + "\n");
            }
            result.append("energy 1: ");
            if (energy.size() >= 1) {
                if (energy.get(0) != null)
                    result.append(energy.get(0).getCardName());
            }
            result.append("\n");
            result.append("energy 2: ");
            if (energy.size() >= 2) {
                if (energy.get(1) != null)
                    result.append(energy.get(1).getCardName());
            }
            result.append("\n");
        }
        printingStringBuilder(result);
    }

    public static void showEnemyInfo(Matcher matcher) {
        if (matcher.matches()) {
            String plceNumber = matcher.group("placenumber");
            int error = 0;
            if (!plceNumber.equals("0") && !plceNumber.equals("1") && !plceNumber.equals("2") && !plceNumber.equals("3")) {
                printingString("invalid place number");
                error = 1;
            }
            if (error == 0 && !doWeHaveAnyPokemonThere(plceNumber)) {
                printingString("no pokemon in the selected place");
                error = 1;
            }
            if (error == 0) {
                showEnemyInfoSupporter(plceNumber);
            }

        }
    }

    private static void showEnemyInfoSupporter(String placeNum) {
        StringBuilder result = new StringBuilder();
        result.append("pokemon: ");
        if (placeNum.equals("0")) {
            if (notCurrentSide.getActive0() != null) {
                ArrayList<Energy> energy = notCurrentSide.getActive0().getEnergyCards();
                result.append(notCurrentSide.getActive0().getCardName() + "\n");
                result.append("special condition: ");
                if (notCurrentSide.getActive0().isAsleep()) result.append("sleep");
                if (notCurrentSide.getActive0().getIsBurning()) result.append("burning");
                result.append("\n");
                result.append("hitpoint: ");
                if (!Double.isNaN((notCurrentSide.getActive0().getRemainingHitPoint())) && !Double.isNaN(notCurrentSide.getActive0().getMaxHitPoint())) {
                    result.append(String.format("%.2f", notCurrentSide.getActive0().getRemainingHitPoint()) + "/" + String.format("%.2f", notCurrentSide.getActive0().getMaxHitPoint()) + "\n");
                }
                result.append("energy 1: ");
                if (energy != null) {
                    if (energy.size() >= 1) {
                        if (energy.get(0) != null)
                            result.append(energy.get(0).getCardName());
                    }
                }
                result.append("\n");
                result.append("energy 2: ");
                if (energy != null) {
                    if (energy.size() >= 2) {
                        if (energy.get(1) != null)
                            result.append(energy.get(1).getCardName());
                    }
                }
                result.append("\n");
            }
        }
        if (placeNum.equals("1")) {
            if (notCurrentSide.getBench1() != null) {
                ArrayList<Energy> energy = notCurrentSide.getBench1().getEnergyCards();
                result.append(notCurrentSide.getBench1().getCardName() + "\n");
                result.append("special condition: ");
                if (notCurrentSide.getBench1().isAsleep()) result.append("sleep");
                if (notCurrentSide.getBench1().getIsBurning()) result.append("burning");
                result.append("\n");
                result.append("hitpoint: ");
                if (!Double.isNaN((notCurrentSide.getBench1().getRemainingHitPoint())) && !Double.isNaN(notCurrentSide.getBench1().getMaxHitPoint())) {
                    result.append(String.format("%.2f", notCurrentSide.getBench1().getRemainingHitPoint()) + "/" + String.format("%.2f", notCurrentSide.getBench1().getMaxHitPoint()) + "\n");
                }
                result.append("energy 1: ");
                if (energy != null) {
                    if (energy.size() >= 1) {
                        if (energy.get(0) != null)
                            result.append(energy.get(0).getCardName());
                    }
                }
                result.append("\n");
                result.append("energy 2: ");
                if (energy != null) {
                    if (energy.size() >= 2) {
                        if (energy.get(1) != null)
                            result.append(energy.get(1).getCardName());
                    }
                }
                result.append("\n");
            }
        }
        if (placeNum.equals("2")) {
            if (notCurrentSide.getBench2() != null) {
                ArrayList<Energy> energy = notCurrentSide.getBench2().getEnergyCards();
                result.append(notCurrentSide.getBench2().getCardName() + "\n");
                result.append("special condition: ");
                if (notCurrentSide.getBench2().isAsleep()) result.append("sleep");
                if (notCurrentSide.getBench2().getIsBurning()) result.append("burning");
                result.append("\n");
                result.append("hitpoint: ");
                if (!Double.isNaN((notCurrentSide.getBench2().getRemainingHitPoint())) && !Double.isNaN(notCurrentSide.getBench2().getMaxHitPoint())) {
                    result.append(String.format("%.2f", notCurrentSide.getBench2().getRemainingHitPoint()) + "/" + String.format("%.2f", notCurrentSide.getBench2().getMaxHitPoint()) + "\n");
                }
                result.append("energy 1: ");
                if (energy != null) {
                    if (energy.size() >= 1) {
                        if (energy.get(0) != null)
                            result.append(energy.get(0).getCardName());
                    }
                }
                result.append("\n");
                result.append("energy 2: ");
                if (energy != null) {
                    if (energy.size() >= 2) {
                        if (energy.get(1) != null)
                            result.append(energy.get(1).getCardName());
                    }
                }
                result.append("\n");
            }
        }
        if (placeNum.equals("3")) {
            if (notCurrentSide.getBench3() != null) {
                ArrayList<Energy> energy = notCurrentSide.getBench3().getEnergyCards();
                result.append(notCurrentSide.getBench3().getCardName() + "\n");
                result.append("special condition: ");
                if (notCurrentSide.getBench3().isAsleep()) result.append("sleep");
                if (notCurrentSide.getBench3().getIsBurning()) result.append("burning");
                result.append("\n");
                result.append("hitpoint: ");
                if (!Double.isNaN((notCurrentSide.getBench3().getRemainingHitPoint())) && !Double.isNaN(notCurrentSide.getBench3().getMaxHitPoint())) {
                    result.append(String.format("%.2f", notCurrentSide.getBench3().getRemainingHitPoint()) + "/" + String.format("%.2f", notCurrentSide.getBench3().getMaxHitPoint()) + "\n");
                }
                result.append("energy 1: ");
                if (energy.size() >= 1) {
                    if (energy.get(0) != null)
                        result.append(energy.get(0).getCardName());
                }
                result.append("\n");
                result.append("energy 2: ");
                if (energy.size() >= 2) {
                    if (energy.get(1) != null)
                        result.append(energy.get(1).getCardName());
                }
                result.append("\n");
            }
        }
        printingStringBuilder(result);
    }

    public static void changeActiveCard(Matcher matcher) {
        if (matcher.matches()) {
            String placeNum = matcher.group("benchnumber");
            int error = 0;
            if (!placeNum.equals("1") && !placeNum.equals("2") && !placeNum.equals("3")) {
                printingString("invalid bench number");
                error = 1;
            }
            if (error == 0 && !doWeHaveAnyPokemonHere(placeNum)) {
                printingString("no pokemon in the selected place");
                error = 1;
            }
            if (currecntSide.getActive0() != null) {
                if (currecntSide.getActive0().isAsleep() && error == 0) {
                    printingString("active pokemon is sleeping");
                    error = 1;
                }
            }
            if (error == 0) {
                printingString("substitution successful");
                swapActiveCard(placeNum);
            }
        }
    }

    private static void swapActiveCard(String placeNum) {
        if (placeNum.equals("1")) {
            Pokemon pokemon0 = currecntSide.getActive0();
            Pokemon pokemon1 = currecntSide.getBench1();
            currecntSide.setBench1(pokemon0);
            currecntSide.setActive0(pokemon1);
        }
        if (placeNum.equals("2")) {
            Pokemon pokemon0 = currecntSide.getActive0();
            Pokemon pokemon2 = currecntSide.getBench2();
            currecntSide.setBench2(pokemon0);
            currecntSide.setActive0(pokemon2);
        }
        if (placeNum.equals("3")) {
            Pokemon pokemon0 = currecntSide.getActive0();
            Pokemon pokemon3 = currecntSide.getBench3();
            currecntSide.setBench3(pokemon0);
            currecntSide.setActive0(pokemon3);
        }

    }
}
