package Controller;

import Model.User;
import View.MainMenuRun;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static View.Print.printingString;

public class LoginMenu {
    public static void registerUser(String input, String regex) {
        Pattern patternForRegister = Pattern.compile(regex);
        Matcher matcherForRegister = patternForRegister.matcher(input);
        if (matcherForRegister.matches()) {
            String userName = matcherForRegister.group("username");
            String password = matcherForRegister.group("password");
            String email = matcherForRegister.group("email");
            String regexForUsername = "[a-zA-Z_]+";
            Pattern patternForUsername = Pattern.compile(regexForUsername);
            Matcher matcherForUsername = patternForUsername.matcher(userName);
            String regexForPassword = "[a-zA-Z].*";
            Pattern patternForPassword = Pattern.compile(regexForPassword);
            Matcher matcherForPassword = patternForPassword.matcher(password);
            String regexForEmail = "^.*@[a-z]*\\.com$";
            Pattern patternForSth = Pattern.compile(regexForEmail);
            Matcher matcherForSth = patternForSth.matcher(email);
            String regexForInEmail = "^[a-zA-Z0-9]*(\\.)?[a-zA-Z0-9]*@[a-z]*\\.com$";
            Pattern patternForAddress = Pattern.compile(regexForInEmail);
            Matcher matcherForAddress = patternForAddress.matcher(email);
            if (!(matcherForUsername.matches())) {
                printingString("username format is invalid");
                return;
            }
            if (isUserReapeted(userName)) {
                printingString("username already exists");
                return;
            }
            if ((password.length() < 6 || password.length() > 18)) {
                printingString("password length too small or short");
                return;
            }
            if (!((password.contains("@")) || (password.contains("#")) ||
                    (password.contains("$")) || (password.contains("^")) ||
                    (password.contains("&")) || password.contains("!"))) {
                printingString("your password must have at least one special character");
                return;
            }
            if (!(matcherForPassword.matches())) {
                printingString("your password must start with english letters");
                return;
            }
            if (!matcherForSth.matches()) {
                printingString("email format is invalid");
                return;
            }
            if (!(matcherForAddress.matches())) {
                printingString("you can't use special characters");
                return;
            }
            User user = new User(userName, password);
            printingString("user registered successfully");
        }
    }

    public static void loginUser(String input, String regex, Scanner scanner) {
        int flagForError = 0;
        Pattern patternForLogin = Pattern.compile(regex);
        Matcher matcher = patternForLogin.matcher(input);
        if (matcher.matches()) {
            String userName = matcher.group("username");
            String password = matcher.group("password");
            ArrayList<User> userNames = User.getUserNames();
            if (!(userNames.contains(userName)) && flagForError == 0) {
                printingString("username doesn't exist");
                flagForError = 1;
            }
            if (User.getUserByUsername(userName) != null) {
                if (!(User.getUserByUsername(userName).getPassword().equals(password)) && flagForError == 0) {
                    printingString("password is incorrect");
                    flagForError = 1;
                }
            }
            if (flagForError == 0) {
                printingString("user logged in successfully");
                User.setLoggedinUser(User.getUserByUsername(userName));
                MainMenuRun.run(scanner);
            }
        }
    }

    public static boolean isUserReapeted(String userName) {
        boolean found = false;
        ArrayList<User> users = User.getUserNames();
        for (int i = 0; i < users.size(); i++) {
            if (userName.equals(users.get(i))) {
                found = true;
            }
        }
        if (found) return true;
        return false;
    }
}
