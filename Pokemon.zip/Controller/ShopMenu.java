package Controller;

import Model.Cards;
import Model.Energy;
import Model.Pokemon;
import Model.User;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static View.Print.printingString;

public class ShopMenu {
    public static void buyCard(String input, String regex) {
        Pattern patternForBuyCard = Pattern.compile(regex);
        Matcher matcher = patternForBuyCard.matcher(input);
        if (matcher.matches()) {
            String cardName = matcher.group("cardname");
            int howManyCoinsINeed = returningValueOfCardForBuy(cardName);
            if (howManyCoinsINeed > User.getLoggedInUser().getCoin()) {
                printingString("not enough coin to buy " + cardName);
                return;
            }
            if (!isCardValid(cardName)) {
                printingString("card name is invalid");
                return;
            }
            printingString("card " + cardName + " bought successfully");
            int newCoins = User.getLoggedInUser().getCoin() - returningValueOfCardForBuy(cardName);
            User.getLoggedInUser().setCoin(newCoins);
            if (isPokemon(cardName)) {
                Cards cards = new Pokemon(cardName, returnType(cardName), isPokemon(cardName), false, false,
                        false, returnresistance(cardName), returnMaxHitPoint(cardName), returnMaxHitPoint(cardName), power(cardName));
                User.getLoggedInUser().addCardsToArrayList(cards);
                assigningWeakness(cards);
            } else {
                Cards cards = new Energy(cardName, returnType(cardName), isPokemon(cardName));
                User.getLoggedInUser().addCardsToArrayList(cards);
            }

        }
    }

    private static void assigningWeakness(Cards cards) {
        if (cards.getIsPokemon()) {
            if (cards.getCardName().equals("dragonite")) {
                if (cards instanceof Pokemon) {
                    ((Pokemon) cards).assigningWeakness(1, 1.2, 1);
                }
            }
            if (cards.getCardName().equals("tepig")) {
                if (cards instanceof Pokemon) {
                    ((Pokemon) cards).assigningWeakness(1, 2, 1.3);
                }
            }
            if (cards.getCardName().equals("lugia")) {
                if (cards instanceof Pokemon) {
                    ((Pokemon) cards).assigningWeakness(1.3, 1, 1);
                }
            }
            if (cards.getCardName().equals("ducklett")) {
                if (cards instanceof Pokemon) {
                    ((Pokemon) cards).assigningWeakness(1, 1, 1.5);
                }
            }
            if (cards.getCardName().equals("pineco")) {
                if (cards instanceof Pokemon) {
                    ((Pokemon) cards).assigningWeakness(1, 1, 1);
                }
            }
            if (cards.getCardName().equals("rowlet")) {
                if (cards instanceof Pokemon) {
                    ((Pokemon) cards).assigningWeakness(1.3, 1, 1);
                }
            }
        }
    }

    private static int returningValueOfCardForBuy(String cardName) {
        if (cardName.equals("dragonite")) {
            return 10;
        }
        if (cardName.equals("tepig")) {
            return 13;
        }
        if (cardName.equals("lugia")) {
            return 11;
        }
        if (cardName.equals("ducklett")) {
            return 15;
        }
        if (cardName.equals("pineco")) {
            return 9;
        }
        if (cardName.equals("rowlet")) {
            return 12;
        }
        if (cardName.equals("pink") || cardName.equals("yellow")) {
            return 5;
        }
        return 0;
    }

    private static boolean isCardValid(String cardName) {
        if ((cardName.equals("dragonite")) || (cardName.equals("tepig")) ||
                (cardName.equals("lugia")) || (cardName.equals("ducklett")) ||
                (cardName.equals("pineco")) || (cardName.equals("rowlet")) ||
                (cardName.equals("pink")) || (cardName.equals("yellow"))) {
            return true;
        }
        return false;
    }

    private static String returnType(String name) {
        if (name.equals("dragonite"))
            return "fire";

        if (name.equals("tepig"))
            return "fire";

        if (name.equals("lugia"))
            return "water";
        if (name.equals("ducklett"))
            return "water";
        if (name.equals("pineco"))
            return "plant";
        if (name.equals("rowlet"))
            return "plant";
        if (name.equals("yellow"))
            return "energy";
        if (name.equals("pink"))
            return "energy";
        return "";
    }

    private static int returningValueOfCardForSell(String cardName) {
        if (cardName.equals("dragonite")) {
            return 8;
        }
        if (cardName.equals("tepig")) {
            return 10;
        }
        if (cardName.equals("lugia")) {
            return 9;
        }
        if (cardName.equals("ducklett")) {
            return 11;
        }
        if (cardName.equals("pineco")) {
            return 7;
        }
        if (cardName.equals("rowlet")) {
            return 9;
        }
        if (cardName.equals("pink") || cardName.equals("yellow")) {
            return 3;
        }
        return 0;
    }

    public static void sellingCards(String input, String regex) {
        Pattern patternForSell = Pattern.compile(regex);
        Matcher matcher = patternForSell.matcher(input);
        if (matcher.matches()) {
            int flagForError = 0;
            String cardName = matcher.group("cardname");
            if (flagForError == 0 && !isCardValid(cardName)) {
                printingString("card name is invalid");
                flagForError = 1;
            }
            if (flagForError == 0 && !doYouHaveThisCardForSell(cardName)) {
                printingString("you don't have this type of card for sell");
                flagForError = 1;
            }
            if (flagForError == 0) {
                User.getLoggedInUser().deleteCards(User.getLoggedInUser().getCardBynameInCards(cardName));
                if (User.getLoggedInUser().getDeckCards().contains(User.getLoggedInUser().getCardBynameInDeckCards(cardName)))
                    User.getLoggedInUser().deleteDeckCards(User.getLoggedInUser().getCardBynameInDeckCards(cardName));
                int gaveMoney = returningValueOfCardForSell(cardName);
                User.getLoggedInUser().setCoin(User.getLoggedInUser().getCoin() + gaveMoney);
                printingString("card " + cardName + " sold successfully");
            }
        }
    }

    private static boolean doYouHaveThisCardForSell(String cardName) {
        int isThere = 0;
        ArrayList<Cards> cards = User.getLoggedInUser().getCards();
        for (int i = 0; i < cards.size(); i++) {
            if (cards.get(i).getCardName().equals(cardName))
                isThere = 1;
        }
        if (isThere == 1) return true;
        return false;
    }

    private static boolean isPokemon(String name) {
        if (name.equals("dragonite") || name.equals("tepig") || name.equals("lugia") || name.equals("ducklett")
                || name.equals("pineco") || name.equals("rowlet")) {
            return true;
        }
        return false;
    }

    private static double returnresistance(String name) {
        if (name.equals("dragonite"))
            return 0.7;

        if (name.equals("tepig"))
            return 0.8;

        if (name.equals("lugia"))
            return 0.7;
        if (name.equals("ducklett"))
            return 0.6;
        if (name.equals("pineco"))
            return 0.9;
        if (name.equals("rowlet"))
            return 0.5;
        return 0;
    }

    private static int power(String name) {
        if (name.equals("dragonite"))
            return 40;

        if (name.equals("tepig"))
            return 25;

        if (name.equals("lugia"))
            return 20;
        if (name.equals("ducklett"))
            return 20;
        if (name.equals("pineco"))
            return 25;
        if (name.equals("rowlet"))
            return 40;
        return 0;
    }

    private static double returnMaxHitPoint(String cardname) {
        if (cardname.equals("dragonite"))
            return 120;
        if (cardname.equals("tepig"))
            return 140;
        if (cardname.equals("lugia"))
            return 90;
        if (cardname.equals("ducklett"))
            return 70;
        if (cardname.equals("pineco"))
            return 110;
        if (cardname.equals("rowlet"))
            return 180;
        return 0;
    }
}
