package Controller;

import Model.Cards;
import Model.User;
import java.util.Collections;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static View.Print.printingString;
import static View.Print.printingStringBuilder;
import static View.ProfileManuRun.cardss;

public class ProfileMenu {
    public static StringBuilder showingStorage(StringBuilder first) {
        ArrayList<Cards> cards = User.getLoggedInUser().getCards();
        int indexForPrinting = 1;
        for (int i = 0; i < cards.size(); i++) {
            first.append(indexForPrinting + ".");
            if (cards.get(i).getCardName().equals("dragonite") || cards.get(i).getCardName().equals("tepig")) {
                first.append("fire ");
                first.append(cards.get(i).getCardName());
                first.append(" ");
                first.append(returningValueOfCard(cards.get(i).getCardName()));
                first.append("\n");
            }
            if (cards.get(i).getCardName().equals("lugia") || cards.get(i).getCardName().equals("ducklett")) {
                first.append("water ");
                first.append(cards.get(i).getCardName());
                first.append(" ");
                first.append(returningValueOfCard(cards.get(i).getCardName()));
                first.append("\n");
            }
            if (cards.get(i).getCardName().equals("pineco") || cards.get(i).getCardName().equals("rowlet")) {
                first.append("plant ");
                first.append(cards.get(i).getCardName());
                first.append(" ");
                first.append(returningValueOfCard(cards.get(i).getCardName()));
                first.append("\n");
            }

            if (cards.get(i).getCardName().equals("pink") || cards.get(i).getCardName().equals("yellow")) {
                first.append("energy ");
                first.append(cards.get(i).getCardName());
                first.append(" ");
                first.append(returningValueOfCard(cards.get(i).getCardName()));
                first.append("\n");
            }
            indexForPrinting++;
        }
        return first;
    }

    private static int returningValueOfCard(String cardName) {
        if (cardName.equals("dragonite")) {
            return 10;
        }
        if (cardName.equals("tepig")) {
            return 13;
        }
        if (cardName.equals("lugia")) {
            return 11;
        }
        if (cardName.equals("ducklett")) {
            return 15;
        }
        if (cardName.equals("pineco")) {
            return 9;
        }
        if (cardName.equals("rowlet")) {
            return 12;
        }
        if (cardName.equals("pink") || cardName.equals("yellow")) {
            return 5;
        }
        return 0;
    }

    public static void addingCard(String input, String regex) {
        Pattern patternForAddingCard = Pattern.compile(regex);
        Matcher matcher = patternForAddingCard.matcher(input);
        if (matcher.matches()) {
            String cardName = matcher.group("cardname");
            int flagForError = 0;
            if (!isCardValid(cardName)) {
                printingString("card name is invalid");
                flagForError = 1;

            }
            if (flagForError == 0 && !doYouHaveThisCard(cardName)) {
                printingString("you don't have this type of card");
                flagForError = 1;

            }
            if (flagForError == 0 && User.getLoggedInUser().getDeckCards().size() == 12) {
                printingString("your deck is already full");
                flagForError = 1;
            }
            if (flagForError == 0 && (!(cardName.equals("yellow") || (cardName.equals("pink"))))) {
                if (doIHaveThisCardinDeck(cardName)) {
                    printingString("you have already added this type of pokemon to your deck");
                    flagForError = 1;
                }
            }
            if (flagForError == 0) {
                printingString("card " + cardName + " equipped to your deck successfully");
                User.getLoggedInUser().setDeckCards(cardss);
                cardss.setIsEqipped(true);
            }
        }
    }

    private static boolean isCardValid(String cardName) {
        if ((cardName.equals("dragonite")) || (cardName.equals("tepig")) ||
                (cardName.equals("lugia")) || (cardName.equals("ducklett")) ||
                (cardName.equals("pineco")) || (cardName.equals("rowlet")) ||
                (cardName.equals("pink")) || (cardName.equals("yellow"))) {
            return true;
        }
        return false;
    }

    private static boolean doYouHaveThisCard(String cardName) {
        int isThere = 0;
        ArrayList<Cards> cards = User.getLoggedInUser().getCards();
        for (int i = 0; i < cards.size(); i++) {
            if (cards.get(i).getCardName().equals(cardName) && !cards.get(i).getIsEqipped()) {

                cardss = cards.get(i);
                return true;
            }
        }

        return false;
    }

    public static void unequipCard(String input, String regex) {
        Pattern patternForUnequip = Pattern.compile(regex);
        Matcher matcher = patternForUnequip.matcher(input);
        int flagForError = 0;
        if (matcher.matches()) {
            String cardName = matcher.group("cardname");
            if (!isCardValid(cardName)) {
                printingString("card name is invalid");
                flagForError = 1;
            }
            if (!doIHaveThisCardinDeck(cardName) && flagForError == 0) {
                printingString("you don't have this type of card in your deck");
                flagForError = 1;
            }
            if (flagForError == 0) {
                printingString("card " + cardName + " unequipped from your deck successfully");
                cardss.setIsEqipped(false);
                User.getLoggedInUser().deleteDeckCards(cardss);
            }
        }
    }

    private static boolean doIHaveThisCardinDeck(String cardName) {
        int flagFound = 0;
        ArrayList<Cards> deckCards = User.getLoggedInUser().getDeckCards();
        for (int j = 0; j < deckCards.size(); j++) {
            if (deckCards.get(j).getCardName().equals(cardName)) {
                flagFound = 1;
                cardss = deckCards.get(j);
                return true;
            }
        }

        return false;
    }

    public static void showDeck() {
        StringBuilder resultForPrinting = new StringBuilder();
        ArrayList<Cards> deckCards = User.getLoggedInUser().getDeckCards();
        int indexOfPrint = 1;
        for (int j = 0; j < deckCards.size(); j++) {
            resultForPrinting.append(indexOfPrint);
            resultForPrinting.append(".");
            resultForPrinting.append(deckCards.get(j).getCardName().toLowerCase());
            resultForPrinting.append("\n");
            indexOfPrint++;
        }
        printingStringBuilder(resultForPrinting);
    }

    public static void showAllRanks() {
        ArrayList<User> users = User.getUsers();
        Collections.sort(users, new Comparator<User>() {
            @Override
            public int compare(User u1, User u2) {
                if (u1.getRank() != u2.getRank()) {
                    return u1.getRank() - u2.getRank(); // Sort by rank
                } else {
                    return u1.getUsername().compareTo(u2.getUsername()); // Sort by username if ranks are equal
                }
            }
        });
        int indexForPrint = 1;
        for (int g = 0; g < users.size(); g++) {
            printingString(indexForPrint + ".username:" + users.get(g).getUsername() + " experience:" + users.get(g).getExperience());
            indexForPrint++;
        }
    }
}
